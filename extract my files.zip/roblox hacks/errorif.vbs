do
X=MsgBox("You Are Hacked!!!!",0+6,"WARNING")
loop